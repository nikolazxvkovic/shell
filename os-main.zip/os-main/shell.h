#ifndef SHELL_SHELL_H
#define SHELL_SHELL_H

#include <stdbool.h>
#include <stdlib.h>

bool parseInputLine(List* lp);


#endif
